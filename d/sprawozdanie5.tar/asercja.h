#include <stdio.h>

void asercja(int a);
