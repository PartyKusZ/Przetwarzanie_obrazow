#include<stdio.h>
#include<math.h>
#include"struktury.h"

void negatyw(t_obraz *obraz, t_opcje *opcje);
void progowanie(t_obraz *obraz, t_opcje *opcje);
void odbicie(t_obraz *obraz, t_opcje *opcje);
void konturowanie(t_obraz *obraz, t_opcje *opcje);
void konwersja(t_obraz *obraz, t_opcje *opcje);
void filtruj(t_obraz *obraz, t_opcje *opcje);
