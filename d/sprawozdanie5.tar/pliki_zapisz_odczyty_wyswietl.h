#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"struktury.h"

#define DL_LINII 1024
int czytaj(t_obraz *obraz, t_opcje *opcje);
void zapisz(t_obraz *obraz, t_opcje *opcje);
void wyswietl(t_opcje *opcje);
